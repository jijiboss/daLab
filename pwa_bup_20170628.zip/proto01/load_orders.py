import sys,os, csv

# Full path to your django project directory
project_dir="/home/sglusa/proto01/pork01"
sys.path.append(project_dir)
# Path to where the settings.py file is
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "proto01.settings")

import django
django.setup()

from pork01.models import Products, Suppliers, Order

# Full path and name to your csv file
csv_filepathname="/home/sglusa/proto01/data/Order.csv"

#For Tab delimited files, use this
#dataReader = csv.reader(open(csv_filepathname), dialect='excel-tab')
#For CSV, use this
dataReader = csv.reader(open(csv_filepathname), delimiter=',', quotechar='"')
for row in dataReader:
	# Ignore the header row, import everything else
	if row[0] != 'order_week':
		order = Order()
		order.order_week = row[0]
		order.order_date = row[1]
		supp = Suppliers.objects.get(supplier=row[2])
		order.supplier = supp
		prod_code = Products.objects.get(prod_code_sumitomo=row[3])
		order.prod_code_sumitomo = prod_code
		order.order_qty = row[4]
		order.fulfill_qty = row[5]
		order.production_date = row[6]
		order.trailer_num = row[7]
		order.port_of_lading = row[8]
		order.port_of_unlading = row[9]
		order.save()