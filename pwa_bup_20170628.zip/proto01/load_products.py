import sys,os, csv

# Full path to your django project directory
project_dir="/home/sglusa/proto01/pork01"
sys.path.append(project_dir)
# Path to where the settings.py file is
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "proto01.settings")

import django
django.setup()

from pork01.models import Products, Suppliers

# Full path and name to your csv file
csv_filepathname="/home/sglusa/proto01/data/Products.csv"

#For Tab delimited files, use this
#dataReader = csv.reader(open(csv_filepathname), dialect='excel-tab')
#For CSV, use this
dataReader = csv.reader(open(csv_filepathname), delimiter=',', quotechar='"')
for row in dataReader:
	# Ignore the header row, import everything else
	if row[0] != 'supplier':
		products = Products()
		#"supplier" below is the field name
		supp = Suppliers.objects.get(supplier=row[0])
		products.supplier = supp
		products.prod_code_supplier = row[1]
		products.item_supplier = row[2]
		products.prod_code_sumitomo = row[3]
		products.item_sumitomo = row[4]
		products.is_favorite = row[5]
		products.save()