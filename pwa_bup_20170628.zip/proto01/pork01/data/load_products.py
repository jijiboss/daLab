# Full path and name to your csv file
csv_filepathname="/home/sglusa/proto01/pork01/data/products.csv"

# Full path to your django project directoryxxx
your_djangoproject_home="/home/sglusa/proto01/pork01"

import sys,os
sys.path.append(your_djangoproject_home)
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "proto01.settings")

from pork01.models import Products
import csv


#For Tab delimited files, use this
#dataReader = csv.reader(open(csv_filepathname), dialect='excel-tab')
#For CSV, use this
dataReader = csv.reader(open(csv_filepathname), delimiter=',', quotechar='"')
for row in dataReader:
	if row[0] != 'supplier':
	# Ignore the header row, import everything else
		products = Products()
		products.supplier = row[0]
		products.prod_code_supplier = row[1]
		products.item_supplier = row[2]
		products.prod_code_sumitomo = row[3]
		products.item_sumitomo = row[4]
		products.is_favorite = row[5]
		products.save()