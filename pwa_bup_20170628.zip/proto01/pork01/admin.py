from django.contrib import admin
from .models import Suppliers, Products, Order, ProductsAdmin, OrderAdmin

admin.site.register(Suppliers)
admin.site.register(Products, ProductsAdmin) #Model must be declared before the AdminModel
admin.site.register(Order, OrderAdmin) #Model must be declared before the AdminModel
