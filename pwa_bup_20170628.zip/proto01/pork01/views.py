from django.http import Http404
from django.shortcuts import render, get_object_or_404
from .models import Suppliers, Products, Order


def index(request):
    all_suppliers = Suppliers.objects.all()
#    template = loader.get_template('pork01/index.html') #Django will automatically look at pork01/template for this path
#    return HttpResponse(template.render(context, request))
    return render(request, 'pork01/index.html', { 'all_suppliers': all_suppliers, })

def supplier_detail(request, supplier_id):
    #    return HttpResponse("<H2>Details for Supplier id: " + str(supplier_id) + "</H2>")
    #replaced by below

    #    try:
    #        supps = Suppliers.objects.get(pk=supplier_id)
    #    except Suppliers.DoesNotExist:
    #        raise Http404("Supplier does not exist")
    #replaced by below

    supps = get_object_or_404(Suppliers, pk=supplier_id)
    #Pass "supps" to the supplier_detai.html page
    return render(request, 'pork01/supplier_detail.html', { 'supps': supps })

def favorite(request, supplier_id):
    supps = get_object_or_404(Suppliers, pk=supplier_id)
    try:
        selected_supplier = supps.products_set.get(pk=request.POST['prods'])
    except (KeyError, Products.DoesNotExist):
        return render(request, 'pork01/supplier_detail.html', {
            'supps': supps,
            'error_message': "You did not select a valid product",
        })
    else:
        selected_supplier.is_favorite=True
        selected_supplier.save()
        return render(request, 'pork01/supplier_detail.html', { 'supps': supps })
