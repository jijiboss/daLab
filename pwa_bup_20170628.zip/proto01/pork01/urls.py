from django.conf.urls import url
from . import views

app_name = 'pork01'

urlpatterns = [
    #/pork01/
    url(r'^$', views.index, name='index'),

    #/pork01/<supplier.id>
    #[0-9]+ => Get as many series of digits between 0 and 9
    #?P<supplier_id => Then assign the value to this variable
    url(r'^(?P<supplier_id>[0-9]+)/$', views.supplier_detail, name='supplier_detail'),

    #/pork01/<supplier.id>/favorite/
    #This is an example of a URL that will execute a logic instead of taking to a new page
    url(r'^(?P<supplier_id>[0-9]+)/favorite/$', views.favorite, name='favorite'),

]