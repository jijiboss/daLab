Django-adaptors is a tool which allow you to transform easily a CSV/XML file into a python object or a django model instance.
It is based on a django-style declarative model.

More information available on read the doc:
http://django-adaptors.readthedocs.org/


