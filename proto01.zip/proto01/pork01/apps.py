from django.apps import AppConfig


class Pork01Config(AppConfig):
    name = 'pork01'
